package ExceptionHandling;

public class LearnException {

	public static void main(String[] args) {

		int x=10;
		int y=2;
		int[] a= {1,2,3,4};
		
		try {
			System.out.println(x/y);
			System.out.println(a[5]);
		}
		catch (ArithmeticException e) {
			System.out.println("Default value can be taken as 1 for division");
			System.out.println(e);
			System.out.println(x/1);
		}catch(ArrayIndexOutOfBoundsException ai) {
			System.out.println(a[2]+ " "+ai);
		}catch(Throwable th) {
			System.out.println(th);
		}
		
		
		System.out.println("End of Program");
		
	}

}
