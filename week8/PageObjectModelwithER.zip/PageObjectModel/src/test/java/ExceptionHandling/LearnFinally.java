package ExceptionHandling;

import java.io.IOException;

public class LearnFinally {

	public static void main(String[] args) throws IOException {
		
		int x=10;
		int y=0;
		
		try {
			System.out.println(x/y);
		}catch(Exception e){
			System.out.println(e);
		}finally {
			System.out.println("End of program");
			Runtime.getRuntime().exec("taskkill /f /im chromedriver.exe");
		}
		
	}

}
