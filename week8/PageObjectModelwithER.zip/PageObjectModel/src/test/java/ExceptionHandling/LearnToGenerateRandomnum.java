package ExceptionHandling;

public class LearnToGenerateRandomnum {

	public static void main(String[] args) {
	 //int random =(int)(Math.random()*999999);
		double r=Math.random()*999999;		
		int random =(int)(Math.random()*999999);
	 System.out.println(r);
	 System.out.println(random);

	}

}
