package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod {
	
	public LeadsPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node =node;
	}
	
	
	public CreateLeadPage clickCreateLead() {
		driver.findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage(driver,node);
	}
	
	public void clickFindLeads() {
		
	}
	
	
	public void clickMergeLead() {
		
	}

}
