package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod {
	
	
	//assign the global driver instance to local instance
	public LoginPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node=node;
		
	}

	
	public LoginPage enterUsername() throws IOException {		
		try {
 		driver.findElement(By.id("username")).sendKeys("demoSalesManager");
		reportStatus("pass","Username is entered successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Username is not entered successfully");
		}
			
		return this; //calling current page constructor
	}	
	
	public LoginPage enterPassword() throws IOException {
		try {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		reportStatus("pass","Password is entered successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Password is not entered successfully");
		}
		return this;
	}
	
	
	public WelcomePage clickLogin() throws IOException {
		try {
		driver.findElement(By.className("decorativeSubmit")).click();
		reportStatus("pass","Login button is clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Login button is not clicked successfully");
		}return new WelcomePage(driver,node);
		
	}
	
	
	
}
